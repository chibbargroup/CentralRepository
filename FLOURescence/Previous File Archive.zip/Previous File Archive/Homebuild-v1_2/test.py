i = 0
while i < 17:
	print("try 1")
	print(i)
	i +=1
	print(i)
	print('Hooray')